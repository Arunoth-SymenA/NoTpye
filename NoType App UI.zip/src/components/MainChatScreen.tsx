import { useState } from "react";
import { Button } from "./ui/button";
import { Card } from "./ui/card";
import { Badge } from "./ui/badge";
import { ScrollArea } from "./ui/scroll-area";
import { Avatar, AvatarFallback } from "./ui/avatar";
import {
  ChevronDown,
  ChevronRight,
  Plus,
  Send,
  Wifi,
  WifiOff,
  User,
  Music,
  Coffee,
  Key,
  Users,
  Mic,
  Camera,
  MessageSquare,
  Check,
} from "lucide-react";

interface MainChatScreenProps {
  userType: string;
  onChangeUserType: () => void;
}

interface Category {
  id: string;
  name: string;
  icon: any;
  subcategories: Subcategory[];
}

interface Subcategory {
  id: string;
  name: string;
  presets: string[];
}

const categories: Category[] = [
  {
    id: "drinks",
    name: "Drinks",
    icon: Coffee,
    subcategories: [
      { id: "hot", name: "Hot", presets: ["Tea", "Coffee", "Hot Chocolate"] },
      { id: "cold", name: "Cold", presets: ["Water", "Juice", "Soda"] },
      { id: "warm", name: "Warm", presets: ["Warm Water", "Herbal Tea"] },
    ],
  },
  {
    id: "stage",
    name: "Stage",
    icon: Mic,
    subcategories: [
      { id: "major", name: "Major", presets: ["Louder", "Softer", "Ready", "Stop"] },
      { id: "minor", name: "Minor", presets: ["Adjust Mic", "Change Song", "Repeat"] },
    ],
  },
  {
    id: "keys",
    name: "Keys",
    icon: Music,
    subcategories: [
      { id: "major-scale", name: "Major", presets: ["C Major", "D Major", "E Major", "G Major"] },
      { id: "minor-scale", name: "Minor", presets: ["A Minor", "D Minor", "E Minor"] },
    ],
  },
  {
    id: "band",
    name: "Band",
    icon: Music,
    subcategories: [
      { id: "tempo", name: "Tempo", presets: ["Faster", "Slower", "Keep Tempo"] },
      { id: "volume", name: "Volume", presets: ["Louder", "Softer", "Good Volume"] },
    ],
  },
  {
    id: "volunteers",
    name: "Volunteers",
    icon: Users,
    subcategories: [
      { id: "help", name: "Help Needed", presets: ["Need Assistance", "Clean Up", "Setup"] },
      { id: "break", name: "Break", presets: ["Taking Break", "Back Soon", "Available"] },
    ],
  },
  {
    id: "media",
    name: "Media",
    icon: Camera,
    subcategories: [
      { id: "slides", name: "Slides", presets: ["Next Slide", "Previous Slide", "Hold Slide"] },
      { id: "recording", name: "Recording", presets: ["Start Recording", "Stop Recording"] },
    ],
  },
];

const recipients = [
  { id: "everyone", name: "Everyone", type: "group" },
  { id: "pastor", name: "Pastor", type: "role" },
  { id: "host", name: "Host", type: "role" },
  { id: "keys1", name: "Keys 1", type: "role" },
  { id: "guitar", name: "Guitar", type: "role" },
  { id: "bass", name: "Bass", type: "role" },
  { id: "drummer", name: "Drummer", type: "role" },
  { id: "media", name: "Media", type: "role" },
  { id: "ushers", name: "Ushers", type: "role" },
  { id: "volunteer", name: "Volunteer", type: "role" },
];

export function MainChatScreen({ userType, onChangeUserType }: MainChatScreenProps) {
  const [expandedCategory, setExpandedCategory] = useState<string | null>(null);
  const [expandedSubcategory, setExpandedSubcategory] = useState<string | null>(null);
  const [selectedRecipients, setSelectedRecipients] = useState<string[]>([]);
  const [selectedPreset, setSelectedPreset] = useState<string | null>(null);
  const [customMessage, setCustomMessage] = useState("");
  const [isConnected, setIsConnected] = useState(true);
  const [sentMessages, setSentMessages] = useState<Array<{ text: string; to: string[]; time: Date }>>([]);

  const toggleCategory = (categoryId: string) => {
    setExpandedCategory(expandedCategory === categoryId ? null : categoryId);
    setExpandedSubcategory(null);
  };

  const toggleSubcategory = (subcategoryId: string) => {
    setExpandedSubcategory(expandedSubcategory === subcategoryId ? null : subcategoryId);
  };

  const toggleRecipient = (recipientId: string) => {
    if (recipientId === "everyone") {
      setSelectedRecipients(["everyone"]);
    } else {
      const newRecipients = selectedRecipients.includes(recipientId)
        ? selectedRecipients.filter((id) => id !== recipientId)
        : [...selectedRecipients.filter((id) => id !== "everyone"), recipientId];
      setSelectedRecipients(newRecipients);
    }
  };

  const handleSendPreset = () => {
    if (selectedPreset && selectedRecipients.length > 0) {
      setSentMessages([...sentMessages, { text: selectedPreset, to: selectedRecipients, time: new Date() }]);
      setSelectedPreset(null);
    }
  };

  const handleSendCustom = () => {
    if (customMessage.trim() && selectedRecipients.length > 0) {
      setSentMessages([...sentMessages, { text: customMessage, to: selectedRecipients, time: new Date() }]);
      setCustomMessage("");
    }
  };

  return (
    <div className="h-screen flex flex-col bg-slate-50">
      {/* Header */}
      <div className="bg-white border-b border-slate-200 px-4 py-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Avatar onClick={onChangeUserType} className="cursor-pointer">
              <AvatarFallback className="bg-blue-100 text-blue-700">
                {userType.charAt(0).toUpperCase()}
              </AvatarFallback>
            </Avatar>
            <div>
              <div className="text-slate-900">{userType}</div>
              <div className="flex items-center gap-1 text-slate-600">
                {isConnected ? (
                  <>
                    <Wifi className="w-3 h-3 text-green-600" />
                    <span className="text-xs">Connected</span>
                  </>
                ) : (
                  <>
                    <WifiOff className="w-3 h-3 text-red-600" />
                    <span className="text-xs">Offline</span>
                  </>
                )}
              </div>
            </div>
          </div>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setIsConnected(!isConnected)}
          >
            {isConnected ? <Wifi className="w-5 h-5" /> : <WifiOff className="w-5 h-5" />}
          </Button>
        </div>
      </div>

      {/* Main Content - Two Panels */}
      <div className="flex-1 flex overflow-hidden">
        {/* Left Panel - Message Categories */}
        <div className="w-1/2 border-r border-slate-200 bg-white flex flex-col">
          <div className="px-4 py-3 border-b border-slate-200 flex items-center justify-between">
            <span className="text-slate-700">Quick Messages</span>
            <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
              <Plus className="w-4 h-4" />
            </Button>
          </div>
          <ScrollArea className="flex-1">
            <div className="p-2 space-y-1">
              {categories.map((category) => {
                const Icon = category.icon;
                const isExpanded = expandedCategory === category.id;
                return (
                  <div key={category.id} className="space-y-1">
                    <Button
                      variant="ghost"
                      onClick={() => toggleCategory(category.id)}
                      className="w-full justify-start gap-2 hover:bg-slate-100"
                    >
                      {isExpanded ? (
                        <ChevronDown className="w-4 h-4 text-slate-400" />
                      ) : (
                        <ChevronRight className="w-4 h-4 text-slate-400" />
                      )}
                      <Icon className="w-4 h-4 text-slate-600" />
                      <span className="text-slate-900">{category.name}</span>
                    </Button>

                    {isExpanded && (
                      <div className="ml-6 space-y-1">
                        {category.subcategories.map((subcategory) => {
                          const isSubExpanded = expandedSubcategory === subcategory.id;
                          return (
                            <div key={subcategory.id} className="space-y-1">
                              <Button
                                variant="ghost"
                                onClick={() => toggleSubcategory(subcategory.id)}
                                className="w-full justify-start gap-2 text-sm hover:bg-slate-100"
                              >
                                {isSubExpanded ? (
                                  <ChevronDown className="w-3 h-3 text-slate-400" />
                                ) : (
                                  <ChevronRight className="w-3 h-3 text-slate-400" />
                                )}
                                <span className="text-slate-700">{subcategory.name}</span>
                              </Button>

                              {isSubExpanded && (
                                <div className="ml-5 space-y-1">
                                  {subcategory.presets.map((preset) => (
                                    <Button
                                      key={preset}
                                      variant="ghost"
                                      onClick={() => setSelectedPreset(preset)}
                                      className={`w-full justify-start text-sm px-3 py-1.5 h-auto ${
                                        selectedPreset === preset
                                          ? "bg-blue-50 text-blue-700"
                                          : "text-slate-600 hover:bg-slate-100"
                                      }`}
                                    >
                                      {preset}
                                    </Button>
                                  ))}
                                </div>
                              )}
                            </div>
                          );
                        })}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </ScrollArea>
        </div>

        {/* Right Panel - Recipients */}
        <div className="w-1/2 bg-white flex flex-col">
          <div className="px-4 py-3 border-b border-slate-200">
            <span className="text-slate-700">Send To</span>
          </div>
          <ScrollArea className="flex-1">
            <div className="p-2 space-y-1">
              {recipients.map((recipient) => {
                const isSelected = selectedRecipients.includes(recipient.id);
                return (
                  <Button
                    key={recipient.id}
                    variant="ghost"
                    onClick={() => toggleRecipient(recipient.id)}
                    className={`w-full justify-start gap-2 ${
                      isSelected
                        ? "bg-blue-50 text-blue-700 hover:bg-blue-100"
                        : "hover:bg-slate-100"
                    }`}
                  >
                    <div
                      className={`w-5 h-5 rounded border-2 flex items-center justify-center ${
                        isSelected
                          ? "bg-blue-600 border-blue-600"
                          : "border-slate-300"
                      }`}
                    >
                      {isSelected && <Check className="w-3 h-3 text-white" />}
                    </div>
                    <User className="w-4 h-4" />
                    <span>{recipient.name}</span>
                  </Button>
                );
              })}
            </div>
          </ScrollArea>
        </div>
      </div>

      {/* Message Preview & Send Area */}
      <div className="bg-white border-t border-slate-200 p-4 space-y-3">
        {selectedPreset && (
          <Card className="p-3 bg-blue-50 border-blue-200">
            <div className="flex items-start justify-between gap-2">
              <div className="flex-1 space-y-1">
                <div className="text-slate-900">{selectedPreset}</div>
                <div className="flex flex-wrap gap-1">
                  {selectedRecipients.map((id) => {
                    const recipient = recipients.find((r) => r.id === id);
                    return (
                      <Badge key={id} variant="secondary" className="text-xs">
                        {recipient?.name}
                      </Badge>
                    );
                  })}
                </div>
              </div>
              <Button
                onClick={handleSendPreset}
                disabled={selectedRecipients.length === 0}
                size="sm"
                className="bg-blue-600 hover:bg-blue-700 gap-1"
              >
                <Send className="w-4 h-4" />
                Send
              </Button>
            </div>
          </Card>
        )}

        <div className="flex gap-2">
          <input
            type="text"
            value={customMessage}
            onChange={(e) => setCustomMessage(e.target.value)}
            onKeyPress={(e) => e.key === "Enter" && handleSendCustom()}
            placeholder="Type custom message..."
            className="flex-1 px-3 py-2 border border-slate-200 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 text-slate-900 placeholder:text-slate-400"
          />
          <Button
            onClick={handleSendCustom}
            disabled={!customMessage.trim() || selectedRecipients.length === 0}
            className="bg-blue-600 hover:bg-blue-700"
          >
            <Send className="w-4 h-4" />
          </Button>
        </div>

        {sentMessages.length > 0 && (
          <div className="text-xs text-green-600 flex items-center gap-1">
            <Check className="w-3 h-3" />
            Last message sent to {sentMessages[sentMessages.length - 1].to.join(", ")}
          </div>
        )}
      </div>
    </div>
  );
}
