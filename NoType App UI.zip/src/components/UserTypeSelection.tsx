import { Button } from "./ui/button";
import { Card } from "./ui/card";
import { Badge } from "./ui/badge";
import { Plus, Music, Mic, Radio, Users, Camera, UserCircle } from "lucide-react";
import { useState } from "react";

interface UserTypeSelectionProps {
  onSelectUserType: (userType: string) => void;
}

const defaultRoles = [
  { name: "Pastor", icon: Mic, color: "bg-purple-100 text-purple-700" },
  { name: "Host", icon: UserCircle, color: "bg-blue-100 text-blue-700" },
  { name: "Keys 1", icon: Music, color: "bg-green-100 text-green-700" },
  { name: "Guitar", icon: Music, color: "bg-green-100 text-green-700" },
  { name: "Bass", icon: Music, color: "bg-green-100 text-green-700" },
  { name: "Drummer", icon: Radio, color: "bg-orange-100 text-orange-700" },
  { name: "Media", icon: Camera, color: "bg-cyan-100 text-cyan-700" },
  { name: "Ushers", icon: Users, color: "bg-slate-100 text-slate-700" },
  { name: "Volunteer", icon: Users, color: "bg-slate-100 text-slate-700" },
];

export function UserTypeSelection({ onSelectUserType }: UserTypeSelectionProps) {
  const [selectedRole, setSelectedRole] = useState<string>("");
  const [customRole, setCustomRole] = useState<string>("");
  const [showCustomInput, setShowCustomInput] = useState(false);

  const handleContinue = () => {
    if (customRole) {
      onSelectUserType(customRole);
    } else if (selectedRole) {
      onSelectUserType(selectedRole);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-50 to-slate-100 p-4">
      <div className="max-w-2xl mx-auto py-8 space-y-6">
        <div className="text-center space-y-2">
          <h1 className="text-slate-900">Select Your Role</h1>
          <p className="text-slate-600">
            Choose your role to help others identify you
          </p>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
          {defaultRoles.map((role) => {
            const Icon = role.icon;
            return (
              <Card
                key={role.name}
                onClick={() => {
                  setSelectedRole(role.name);
                  setShowCustomInput(false);
                  setCustomRole("");
                }}
                className={`p-4 cursor-pointer transition-all hover:shadow-md ${
                  selectedRole === role.name
                    ? "ring-2 ring-blue-500 bg-blue-50"
                    : "hover:bg-slate-50"
                }`}
              >
                <div className="flex flex-col items-center gap-2 text-center">
                  <div className={`w-12 h-12 rounded-full flex items-center justify-center ${role.color}`}>
                    <Icon className="w-6 h-6" />
                  </div>
                  <span className="text-slate-900">{role.name}</span>
                </div>
              </Card>
            );
          })}

          <Card
            onClick={() => {
              setShowCustomInput(true);
              setSelectedRole("");
            }}
            className={`p-4 cursor-pointer transition-all hover:shadow-md ${
              showCustomInput
                ? "ring-2 ring-blue-500 bg-blue-50"
                : "hover:bg-slate-50"
            }`}
          >
            <div className="flex flex-col items-center gap-2 text-center">
              <div className="w-12 h-12 rounded-full flex items-center justify-center bg-slate-100 text-slate-700">
                <Plus className="w-6 h-6" />
              </div>
              <span className="text-slate-900">Custom Role</span>
            </div>
          </Card>
        </div>

        {showCustomInput && (
          <Card className="p-4">
            <input
              type="text"
              value={customRole}
              onChange={(e) => setCustomRole(e.target.value)}
              placeholder="Enter custom role name"
              className="w-full px-3 py-2 border border-slate-200 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              autoFocus
            />
          </Card>
        )}

        <Button
          onClick={handleContinue}
          disabled={!selectedRole && !customRole}
          className="w-full bg-blue-600 hover:bg-blue-700"
        >
          Continue
        </Button>
      </div>
    </div>
  );
}
