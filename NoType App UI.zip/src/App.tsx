import { useState } from "react";
import { LoginScreen } from "./components/LoginScreen";
import { UserTypeSelection } from "./components/UserTypeSelection";
import { MainChatScreen } from "./components/MainChatScreen";

type Screen = "login" | "userTypeSelection" | "chat";

export default function App() {
  const [currentScreen, setCurrentScreen] = useState<Screen>("login");
  const [userType, setUserType] = useState<string>("");

  const handleLogin = (method: 'google' | 'guest') => {
    setCurrentScreen("userTypeSelection");
  };

  const handleSelectUserType = (type: string) => {
    setUserType(type);
    setCurrentScreen("chat");
  };

  const handleChangeUserType = () => {
    setCurrentScreen("userTypeSelection");
  };

  return (
    <div className="min-h-screen">
      {currentScreen === "login" && <LoginScreen onLogin={handleLogin} />}
      {currentScreen === "userTypeSelection" && (
        <UserTypeSelection onSelectUserType={handleSelectUserType} />
      )}
      {currentScreen === "chat" && (
        <MainChatScreen userType={userType} onChangeUserType={handleChangeUserType} />
      )}
    </div>
  );
}
