
  # NoType App UI

  This is a code bundle for NoType App UI. The original project is available at https://www.figma.com/design/mhvnkZTMkWIEjnhaFgjB7L/NoType-App-UI.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  